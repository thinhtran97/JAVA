package assignment1;

import java.util.Scanner;
class LuckyNumber {
  public static int luckyNumber;
	public static int guess;
	public static String answer;
	public static int count;
	public static int totalGames;
	public static int totalGuess;
	public static int guessAvg;
	public static int min ;
	public static final int MAX = 100;
	
	
	public static void main(String[] args) {
		System.out.println("Tôi đang nghĩ một số trong khoảng từ 0 đến 100..");
		play();
		report();
	}
	
	
	// HÀM CHO NGƯỜI DÙNG CHƠI:
	public static void play() {
		Scanner sc = new Scanner(System.in);
		String a = "yes";
		String b = "y";
		count = 1;
//      Không reset vì gọi đệ quy
//		totalGames=0;
//      totalGuess = 1;
//    	min = 1;
		System.out.println("Bạn đoán?");
		
		
		// TÌM SỐ MAY MẮN:
		luckyNumber = (int)(Math.random() * MAX);
		System.out.println("Lucky Number =  " + luckyNumber);
		// NHẬP SỐ DỰ ĐOÁN CỦA BẠN:
		guess = sc.nextInt();
		
		do {
				if(guess < luckyNumber) {
	        		System.out.println("Số may mắn lớn hơn số dự đoán của bạn\nBạn đoán?");
	        	}else if(guess > luckyNumber) {
	        		System.out.println("Số may mắn nhỏ hơn số dự đoán của bạn\nBạn đoán?");	
	        	}
				// IN RA SỐ LẦN DỰ ĐOÁN TRONG TỪNG LẦN CHƠI:
	        	count++;
      // Không tìm min ở đây, ra ngoài while mới tìm min
	        	//min;
      // Dòng này kg cộng dồn ở đây, chờ đoán đúng mới += count
	        	//totalGuess+=count;
	        	guess = sc.nextInt();        	
		} while(guess!=luckyNumber);
		
		
	     System.out.println("Chúc mừng bạn đã đoán đúng con số may mắn sau " + count + " lần dự đoán!\nbạn có muốn tiếp tục chơi không?");
	     // TÌM TỔNG SỐ LẦN CHƠI VÀ TỔNG SỐ LẦN DỰ ĐOÁN:
	     totalGames++;
	     totalGuess+=count;
	     
	     
	     // TÌM SỐ LẦN DỰ ĐOÁN ÍT NHẤT(biến min):
		    if(totalGames ==1) {
		    	//System.out.println("vao totalgame=1");
		    	min = count;
		    }else {
		    	//System.out.println("vao totalgame khac 1");
		     if(count < min ) {
		    	// System.out.println("vao count<min");
		    	 min = count;
		     }
		    }
		    
	     
		// NHẬP “y”, “Y”, “yes”, “YES”, “Yes”   để tiếp tục chơi tiếp:
	     answer= sc.next();
	     if(answer.equalsIgnoreCase(a)) {
	    	 play();	 
	     }else if(answer.equalsIgnoreCase(b)){
	    	 play(); 
	     }
		    // nếu NHẬP không phải CÁC TRƯỜNG HỢP TRÊN thì In ra REPORT.
	}
	
	
	//HÀM IN RA THÔNG BÁO KHI NGƯỜI DÙNG KHÔNG MUỐN TIẾP TỤC CHƠI:
	public static void report() {
		System.out.println("Kết quả tổng quát của trò chơi:");
		System.out.println("Tổng số lần chơi = " + totalGames);
		System.out.println("Tổng số lần dự đoán = " + totalGuess);
		System.out.println("Số lần dự đoán trung bình mỗi lượt = " + Math.round(((float)totalGuess/totalGames)*100)/100.0);
		System.out.println("số lần dự đoán ít nhất = " + min);
	}
}