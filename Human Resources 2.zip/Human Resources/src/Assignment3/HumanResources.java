package Assignment3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

import javax.sql.rowset.spi.TransactionalWriter;

public class HumanResources {
       public static int luaChon;
       public static int banChon;
       public static int slnv;
       public static ArrayList<Staff> staffs = new ArrayList<Staff>();
       public static ArrayList<Department> departments = new ArrayList<Department>();
       
       
	
	public static void main(String[] args) {
		
		

		Department c1 = new Department("HC", "Hành chính nhân sự", 1);
		Department c2 = new Department("IT", "Công nghệ thông tin", 1);
		Department c3 = new Department("MKT", "Marketing", 1);
		departments.add(c1);
		departments.add(c2);
		departments.add(c3);
		
		Employee s1 = new Employee("E001", "Tran Lan", 28, 4.5, "10/10/2020", 5, "Hành chính nhân sự", 4);
		Employee s2 = new Employee("E002", "nguyen na", 34, 4.6, "10/10/1020", 8, "Công nghệ thông tin", 6);
		Employee s3 = new Employee("E002", "lan anh", 34, 4, "10/10/1020", 8, "Công nghệ thông tin", 6);
		Manager d1 = new Manager("M001", "Tran La" , 24, 6.5, "22/02/2012", 1, "Marketing", "Business Leader", 8000000);
		Manager d2 = new Manager("M002", "Q A" , 54, 7.5, "21/02/2022", 1, "Hành chính nhân sự", "Project Leader", 5000000);
		Manager d3 = new Manager("M002", "T F" , 42, 5.5, "19/05/2002", 1, "Công nghệ thông tin", "Technical Leader", 6000000);
		staffs.add(s1);
		staffs.add(s2);
		staffs.add(s3);
		staffs.add(d1);
		staffs.add(d2);
		staffs.add(d3);
		
		while(true) {
		Menu();
		if(luaChon == 1)chucNang1();
		if(luaChon == 2)chucNang2();
		if(luaChon == 3)chucNang3();
		if(luaChon == 4)chucNang4();
		if(luaChon == 5)chucNang5();
		if(luaChon == 6)chucNang6();
	    if(luaChon == 7)chucNang7();
		if(luaChon == 0)break;
		}
	}
	
	// MENU ĐỂ BẠN LỰA CHỌN:
	public static void Menu() {
		Scanner sc = new Scanner(System.in);
		System.out.println("1. Hiển thị danh sách nhân viên hiện có trong công ty.");
		System.out.println("2. Hiển thị các bộ phân trong công ty.");
		System.out.println("3. Hiển thị các nhân viên theo từng bộ phận.");
		System.out.println("4. Thêm nhân viên mới vào công ty.");
		System.out.println("5. Tìm kiếm thông tin nhân viên theo tên hoặc mã nhân viên.");
		System.out.println("6. Hiển thị bảng lương của nhân viên toàn công ty.");
		System.out.println("7. Hiển thị bảng lương của nhân viên theo thứ tự tăng dần.");
		System.out.println("0. Thoát chương trình.");
		System.out.print("Lựa chọn của bạn: ");
		luaChon = sc.nextInt();
		sc.nextLine();
		
	}
	
	//Hiển thị danh sách nhân viên hiện có trong công ty:
	public static void chucNang1() {
		System.out.printf("%-20s | %-50s | %-30s |%-20s | %-50s | %-30s |%-20s | %-50s | %-30s |%n", "Mã Nhân Viên", "Tên Nhân Viên", "Tuổi", "HS Lương", "Ngày Vào Làm", "Ngày Nghỉ Phép", "Bộ Phận", "Số Giờ Làm Thêm/Chức Vụ", "Lương");
		
		for (int i=0; i < staffs.size(); i++) {
			staffs.get(i).displayInformation();
		}
		System.out.println(" ");
	}
	
	//Hiển thị các bộ phận trong công ty.
	public static void chucNang2() {
		// Cập nhật số lượng nhân viên hiện có của từng bộ phận nếu danh sách nhân viên có sẵn: 
		for (int i=0; i < departments.size(); i++) {
			slnv = 0;
			for (int j = 0; j < staffs.size(); j++ ) {
				if(departments.get(i).getTenBoPhan().equals(staffs.get(j).getBoPhan())){
					slnv++ ;
				} departments.get(i).setNhanVienHienTai(slnv);
			}
		}
        //Sau khi cập nhật thì hiển thị các bộ phận của cty:
		System.out.printf("%-20s | %-50s | %-30s |%n", "Mã Bộ Phận", "Tên Bộ Phận", "Số Lượng Nhân Viên Hiện Tại");
		for (int i=0; i < departments.size(); i++) {
			System.out.println(departments.get(i).toString());
		}
		System.out.println(" ");
	}
	
	//Hiển thị các nhân viên theo từng bộ phận:
	public static void chucNang3() {
		
		for (int i=0; i < departments.size(); i++) {
			slnv = 0;
			System.out.println(departments.get(i).getTenBoPhan());
			for (int j = 0; j < staffs.size(); j++ ) {
				if(departments.get(i).getTenBoPhan().equals(staffs.get(j).getBoPhan())){
					staffs.get(j).displayInformation();
					slnv++ ;
				} departments.get(i).setNhanVienHienTai(slnv);
			}
			System.out.println(" ");
		}
		
	}
	
	//Thêm nhân viên thông thường:
	public static void chucNang4() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("1. Thêm nhân viên thông thường");
		System.out.println("2. Thêm nhân viên là cấp quản lí (có thêm chức vụ)");
		System.out.print("Bạn chọn: ");
		banChon = sc.nextInt();
		sc.nextLine();
		
		// Trường hợp 1: Thêm nhân viên Thông Thường:
		if(banChon == 1) {
			System.out.print("Nhập mã nhân viên: ");
			String mnv = sc.nextLine();

			
			System.out.print("Nhập tên nhân viên: ");
			String tennv = sc.nextLine();
			
			
			System.out.print("Nhập tuổi nhân viên: ");
			int tuoinv = sc.nextInt();
			
			
			System.out.print("Nhập hệ số lương của nhân viên: ");
			double hsluong = sc.nextDouble();
			
			sc.nextLine();
			System.out.print("Nhập ngày vào làm của nhân viên: ");
			String nvl = sc.nextLine();
			
			System.out.print("Nhập số ngày nghỉ phép của nhân viên: ");
			int nnp = sc.nextInt();
			
			System.out.println("1. HC - Hành chính nhân sự");
			System.out.println("2. IT - Công nghệ thông tin");
			System.out.println("3. MKT - Marketing");
			System.out.print("Bạn chọn bộ phận: ");
			int bc = sc.nextInt();
			String bp;
			if(bc == 1)bp = "Hành chính nhân sự";
			else if (bc == 2) bp = "Công nghệ thông tin";
			else if (bc == 3) bp = "Marketing";
			else bp ="";
			
			System.out.print("Nhập số giờ làm thêm: ");
			int sglt = sc.nextInt();
			
			staffs.add(new Employee(mnv, tennv, tuoinv, hsluong, nvl, nnp, bp, sglt));	
			
			// Cập nhật số lượng nhân viên của từng bộ phận:
			for (int i=0; i < departments.size(); i++) {
				if(departments.get(i).getTenBoPhan().equals(bp)) {
					departments.get(i).setNhanVienHienTai(departments.get(i).getNhanVienHienTai()+1);
				}
			}
			
		}
		
		//Trường hợp 2: Thêm nhân viên là cấp quản lí (có thêm chức vụ):
		if(banChon == 2) {
			System.out.print("Nhập mã nhân viên: ");
			String mnv = sc.nextLine();
			
			
			System.out.print("Nhập tên nhân viên: ");
			String tennv = sc.nextLine();
			
			
			
			System.out.print("Nhập tuổi nhân viên: ");
			int tuoinv = sc.nextInt();
				
			System.out.print("Nhập hệ số lương của nhân viên: ");
			double hsluong = sc.nextDouble();
			
			sc.nextLine();
			System.out.print("Nhập ngày vào làm của nhân viên: ");
			String nvl = sc.nextLine();
			
		
			System.out.print("Nhập số ngày nghỉ phép của nhân viên: ");
			int nnp = sc.nextInt();
			
			System.out.println("1. HC - Hành chính nhân sự");
			System.out.println("2. IT - Công nghệ thông tin");
			System.out.println("3. MKT - Marketing");
			System.out.print("Bạn chọn bộ phận: ");
			int bc = sc.nextInt();
			String bp;
			if(bc == 1)bp = "Hành chính nhân sự";
			else if (bc == 2) bp = "Công nghệ thông tin";
			else if (bc == 3) bp = "Marketing";
			else bp ="";
			
			System.out.println("Chức danh:");
			System.out.println("1. Business Leader");
			System.out.println("2. Project Leader");
			System.out.println("3.Technical Leader");
			
			System.out.print("Nhập chức danh: ");
			int ncd = sc.nextInt();
			String cd;
			int ltn;
			if(ncd == 1) {cd = "Business Leader"; ltn = 8000000;}
			else if (ncd == 2) {cd = "Project Leader"; ltn = 5000000;}
			else if (ncd == 3) {cd = "Technical Leader"; ltn = 6000000;}
			else {cd =""; ltn = 0;}
			
			
			staffs.add(new Manager(mnv, tennv, tuoinv, hsluong, nvl, nnp, bp, cd, ltn));
			
			// Cập nhật số lượng nhân viên của từng bộ phận:
            for (int i=0; i < departments.size(); i++) {
				if(departments.get(i).getTenBoPhan().equals(bp)) {
					departments.get(i).setNhanVienHienTai(departments.get(i).getNhanVienHienTai()+1);
				}	
			}
		}
		System.out.println(" ");
	}
	
	//Tìm kiếm thông tin nhân viên theo tên hoặc mã nhân viên:
	public static void chucNang5(){
		Scanner sc = new Scanner(System.in);
		System.out.println("1. Tìm nhân viên bằng tên:");
		System.out.println("2. Tìm nhân viên bằng mã nhân viên:");
		System.out.print("Bạn chọn");
		banChon = sc.nextInt();
		String tnv;
		String mnv;
		sc.nextLine();
		// Trường hợp 1: Tìm kiếm nhân viên theo tên:
		if (banChon == 1) {
			System.out.println("Nhập tên nhân viên cần tìm ");
			tnv = sc.nextLine();
			for (int i=0; i < staffs.size(); i++) {
				if(staffs.get(i).getTenNhanVien().contains(tnv)) {
					System.out.printf("%-10s | %-50s | %-10s |%-10s | %-30s | %-10s |%-40s | %-30s | %-20s |%n", "Mã Nhân Viên", "Tên Nhân Viên", "Tuổi", "HS Lương", "Ngày Vào Làm", "Ngày Nghỉ Phép", "Bộ Phận", "Số Giờ Làm Thêm/Chức Vụ", "Lương");
					staffs.get(i).displayInformation();
				}
			}
		}
		
		
		//Trường hợp 2: Tìm kiếm nhân viên theo mã nhân viên:
		if (banChon == 2) {
			System.out.println("Nhập mã nhân viên cần tìm");
			mnv = sc.nextLine();
			for (int i=0; i < staffs.size(); i++) {
				if(staffs.get(i).getTenNhanVien().contains(mnv)) {
					System.out.printf("%-10s | %-50s | %-10s |%-10s | %-30s | %-10s |%-40s | %-30s | %-20s |%n", "Mã Nhân Viên", "Tên Nhân Viên", "Tuổi", "HS Lương", "Ngày Vào Làm", "Ngày Nghỉ Phép", "Bộ Phận", "Số Giờ Làm Thêm/Chức Vụ", "Lương");
					staffs.get(i).displayInformation();
				}
			}
		}
		System.out.println(" ");
	}
	
	// Hiển thị bảng lương của nhân viên toàn công ty (theo thứ tự giảm dần):
	public static void chucNang6(){
		// Cách 1 (Ép kiểu xuống subclass):
//		Comparator <Staff> luongGiamDan = new Comparator <Staff>(){
//			public int compare(Staff l1, Staff l2) {
//				double salary1 = 0.0;
//				double salary2 = 0.0;
//				if(l1 instanceof Employee) {
//					Employee emp1 = (Employee) l1;
//					salary1 = emp1.calculateSalary();
//				}else if (l1 instanceof Manager) {
//					Manager man1 = (Manager) l1;
//					salary1 = man1.calculateSalary();	
//				}
//				
//				if(l2 instanceof Employee) {
//					Employee emp2 = (Employee) l2;
//					salary2 = emp2.calculateSalary();
//				}else if (l2 instanceof Manager) {
//					Manager man2 = (Manager) l2;
//					salary2 = man2.calculateSalary();	
//				}
//				
//				if(salary1 > salary2) {
//					return -1;
//				}else if (salary1 < salary2) {
//					return 1;		
//				}
//				return 0;		
//			}
//		};
//		
		//CÁCH 2 (Ép kiểu sang interface):
			Comparator <Staff> luongGiamDan = new Comparator <Staff>(){
				public int compare(Staff l1, Staff l2) {
					if(((ICalculator)l1).calculateSalary() > ((ICalculator)l2).calculateSalary()) {
						return -1;
					}else if (((ICalculator)l1).calculateSalary() < ((ICalculator)l2).calculateSalary()) {
						return 1;		
					}
					return 0;
					
				}
			};
		staffs.sort(luongGiamDan);
		
        System.out.printf("%-20s | %-50s | %-30s |%-20s | %-50s | %-30s |%-20s | %-50s | %-30s |%n", "Mã Nhân Viên", "Tên Nhân Viên", "Tuổi", "HS Lương", "Ngày Vào Làm", "Ngày Nghỉ Phép", "Bộ Phận", "Số Giờ Làm Thêm/Chức Vụ", "Lương");	
		for (int i=0; i < staffs.size(); i++) {
			staffs.get(i).displayInformation();
		}
		System.out.println(" ");
	}
	
	//Hiển thị bảng lương của nhân viên theo thứ tự tăng dần:
	public static void chucNang7(){
		// CÁCH 1 (Ép kiểu xuống subclass):
//		Comparator <Staff> luongTangDan = new Comparator <Staff>(){
//			public int compare(Staff l1, Staff l2) {
//				double salary1 = 0.0;
//				double salary2 = 0.0;
//				if(l1 instanceof Employee) {
//					Employee emp1 = (Employee) l1;
//					salary1 = emp1.calculateSalary();
//				}else if (l1 instanceof Manager) {
//					Manager man1 = (Manager) l1;
//					salary1 = man1.calculateSalary();	
//				}
//				
//				if(l2 instanceof Employee) {
//					Employee emp2 = (Employee) l2;
//					salary2 = emp2.calculateSalary();
//				}else if (l2 instanceof Manager) {
//					Manager man2 = (Manager) l2;
//					salary2 = man2.calculateSalary();	
//				}
//				
//				if(salary1 > salary2) {
//					return 1;
//				}else if (salary1 < salary2) {
//					return -1;		
//				}
//				return 0;		
//			}
//		};

		
//		CÁCH 2 (Ép kiểu sang interface):
		Comparator <Staff> luongTangDan = new Comparator <Staff>(){
			public int compare(Staff l1, Staff l2) {
				if(((ICalculator)l1).calculateSalary() > ((ICalculator)l2).calculateSalary()) {
					return 1;
				}else if (((ICalculator)l1).calculateSalary() < ((ICalculator)l2).calculateSalary()) {
					return -1;		
				}
				return 0;
				
			}
		};
		
		staffs.sort(luongTangDan);
        System.out.printf("%-20s | %-50s | %-30s |%-20s | %-50s | %-30s |%-20s | %-50s | %-30s |%n", "Mã Nhân Viên", "Tên Nhân Viên", "Tuổi", "HS Lương", "Ngày Vào Làm", "Ngày Nghỉ Phép", "Bộ Phận", "Số Giờ Làm Thêm/Chức Vụ", "Lương");
		for (int i=0; i < staffs.size(); i++) {
			staffs.get(i).displayInformation();
		}
		System.out.println(" ");
	}



}
