package Assignment3;

public interface ICalculator {
	public double calculateSalary();
}
