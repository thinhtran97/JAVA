package Assignment3;

public class Employee extends Staff implements ICalculator{
	private int soGioLamThem;
	
	public Employee (String maNhanVien, String tenNhanVien, int tuoiNhanVien, double heSoLuong, String ngayVaoLam, int ngayNghiPhep, String boPhan, int soGioLamThem) {
		super( maNhanVien, tenNhanVien, tuoiNhanVien, heSoLuong, ngayVaoLam, ngayNghiPhep, boPhan);
		this.soGioLamThem = soGioLamThem;
	}
	
	public int getSoGioLamThem () {
		return soGioLamThem;
	}
	
	public void setSoGioLamThem(int soGioLamThem) {
		this.soGioLamThem = soGioLamThem;
	}
	
	@Override
	public void displayInformation() {
		System.out.printf("%-20s | %-50s | %-30d |%-20f | %-50s | %-30d |%-20s | %-50d | %-30f |%n", getMaNhanVien(), getTenNhanVien(), getTuoiNhanVien(), getHeSoLuong(), getNgayVaoLam(), getNgayNghiPhep(), getBoPhan(), soGioLamThem, calculateSalary());
	}
	
	@Override
	public double calculateSalary() {
		return ((getHeSoLuong() * 3000000) + (soGioLamThem * 200000));
	}
	

}
