package Assignment3;

public class Department {
private String maBoPhan ;
private String tenBoPhan;
private int nhanVienHienTai;
 
  public Department (String maBoPhan, String tenBoPhan, int nhanVienHienTai) {
	 this.maBoPhan = maBoPhan;
	 this.tenBoPhan = tenBoPhan;
	 this.nhanVienHienTai = nhanVienHienTai;
 }
 
 public String getMaBoPhan() {
	 return maBoPhan;
 }
 
 public void setMaBoPhan(String maBoPhan) {
	 this.maBoPhan = maBoPhan;
 }
 
 public String getTenBoPhan() {
	 return tenBoPhan;
 }
 
 public void setTenBoPhan(String tenBoPhan) {
	 this.tenBoPhan = tenBoPhan;
 }
 
 public int getNhanVienHienTai(){
	 return nhanVienHienTai;
 }
 
 public void setNhanVienHienTai(int nhanVienHienTai) {
	 this.nhanVienHienTai = nhanVienHienTai;
 }
 
 
  public String toString() {
	  return String.format("%-20s | %-50s | %-30d |%n", maBoPhan, tenBoPhan, nhanVienHienTai);
	
}
}
