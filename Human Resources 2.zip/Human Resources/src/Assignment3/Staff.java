package Assignment3;


// Lớp Staff không được implements interface ICalculator

public abstract class Staff {
   private String maNhanVien;
   private String tenNhanVien;
   private int tuoiNhanVien;
   private double heSoLuong; 
   private String ngayVaoLam;
   private int ngayNghiPhep;
   private String boPhan;
   
   public Staff(String maNhanVien, String tenNhanVien, int tuoiNhanVien, double heSoLuong, String ngayVaoLam, int ngayNghiPhep, String boPhan) {
	   this.maNhanVien = maNhanVien;
	   this.tenNhanVien = tenNhanVien;
	   this.tuoiNhanVien = tuoiNhanVien;
	   this.heSoLuong = heSoLuong;
	   this.ngayVaoLam = ngayVaoLam;
	   this.ngayNghiPhep = ngayNghiPhep;
	   this.boPhan = boPhan;
   }
	
	public abstract void displayInformation();
	
	public String getMaNhanVien() {
		return maNhanVien;
	}
	public void setMaNhanVien(String maNhanVien) {
		this.maNhanVien = maNhanVien;
	}
	
	public String getTenNhanVien() {
		return tenNhanVien;
	}
	public void setTenNhanVien(String tenNhanVien) {
		this.tenNhanVien = tenNhanVien;
	} 
	
	public int getTuoiNhanVien() {
		return tuoiNhanVien;
	}
	public void setTuoiNhanVien(int tuoiNhanVien) {
		this.tuoiNhanVien = tuoiNhanVien;
	} 
	
	public double getHeSoLuong() {
		return heSoLuong;
	}
	public void setHeSoLuong(double heSoLuong) {
		this.heSoLuong = heSoLuong;
	} 
	
	public String getNgayVaoLam() {
		return ngayVaoLam;
	}
	public void setNgayVaoLam(String ngayVaoLam) {
		this.ngayVaoLam = ngayVaoLam;
	}
	
	public int getNgayNghiPhep() {
		return ngayNghiPhep;
	}
	public void setNgayNghiPhep(int ngayNghiPhep) {
		this.ngayNghiPhep = ngayNghiPhep;
	} 
	
	public String getBoPhan() {
		return boPhan;
	}
	public void setBoPhan(String boPhan) {
		this.boPhan = boPhan;
	} 
	
}
