package Assignment3;
// 
public class Manager extends  Staff implements ICalculator{
	private String chucDanh;
	private int luongTrachNhiem;
	
	public Manager (String maNhanVien, String tenNhanVien, int tuoiNhanVien, double heSoLuong, String ngayVaoLam, int ngayNghiPhep, String boPhan, String chucDanh, int luongTrachNhiem) {
		super( maNhanVien, tenNhanVien, tuoiNhanVien, heSoLuong, ngayVaoLam, ngayNghiPhep, boPhan);
		this.chucDanh = chucDanh;
		this.luongTrachNhiem =luongTrachNhiem;	
	}
	
	public String getChucDanh() {
		return chucDanh;
	}
	
	public void setChucDanh(String chucDanh) {
		this.chucDanh = chucDanh;
	}
	
	public int getLuongTrachNhiem() {
		return luongTrachNhiem;
	}
	
	public void setLuongTrachNhiem(int luongTrachNhiem) {
		this.luongTrachNhiem = luongTrachNhiem;
	}
	
	@Override
	public void displayInformation() {
		System.out.printf("%-20s | %-50s | %-30d |%-20f | %-50s | %-30d |%-20s | %-50s | %-30f |%n", getMaNhanVien(), getTenNhanVien(), getTuoiNhanVien(), getHeSoLuong(), getNgayVaoLam(), getNgayNghiPhep(), getBoPhan(), chucDanh, calculateSalary());

	}
	
	@Override
	public double calculateSalary() {
		return (getHeSoLuong() * 5000000 + luongTrachNhiem);
	}
}
