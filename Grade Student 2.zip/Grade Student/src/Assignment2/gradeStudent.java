package Assignment2;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;

class gradeStudent {
  public static int weightMidTerm;
  public static int weightFinalTerm;
  public static int weightHomeWork;
  public static int scoreEarnedMidTerm;
  public static int scoreEarnedFinalTerm;
  public static int WereScoresShiftedMidTerm;
  public static int WereScoresShiftedFinalTerm;
  public static int shiftAmountMidTerm;
  public static int shiftAmountFinalTerm;
  public static int totalPointsMidTerm;
  public static int totalPointsFinalTerm;
  public static double weightedScoreMidTerm;
  public static double weightedScoreFinalTerm;
  public static double weightedScoreHomeWork;
  public static int numOfAss;
  public static int score;
  public static int max;
  public static int totalAssScore;
  public static int totalAssMax;
  public static int attend;
  public static int totalSectionPoint;
  public static double overallPercentage;
  public static double GPA;
  
  
  public static void main(String[] args) {
    begin();
    midTerm();
    finalTerm();
    homework(); 
    report();
  }

  // Hiển thị thông báo mô tả ngắn gọn về chương trình:
  public static void begin(){
    System.out.println("This program reads exam/homework scores and reports your overall course grade.");
    System.out.println();
  }
  
// Sau đó, người dùng sẽ nhập và tính điểm thi giữa kỳ - Midterm:
  public static double midTerm(){
 System.out.println("Midterm: ");
    Scanner sc = new Scanner(System.in);
    
    
  while(true){
    System.out.print("Weight  (0 - 100)?  ");
    weightMidTerm = sc.nextInt();
    if(weightMidTerm < 0 || weightMidTerm > 100){
      System.out.println("Bạn đã nhập sai");
    }else{
      break;
    }
  }
  String wm = String.valueOf(weightMidTerm);
    
  while(true) {  
      System.out.print("Score earned?   ");
  scoreEarnedMidTerm = sc.nextInt();
       if(scoreEarnedMidTerm < 0 || scoreEarnedMidTerm >100) {
  	        System.out.println("Vui lòng nhập trong khoảng từ 0 - 100");
       }else {
  	      break;
        }
  }
    
        System.out.print("Were scores shifted (1 = yes, 2=no)?  ");
    WereScoresShiftedMidTerm = sc.nextInt();
    
    if(WereScoresShiftedMidTerm == 1){
        System.out.print("Shift amount?  ");
    shiftAmountMidTerm = sc.nextInt();  
    }

    totalPointsMidTerm = scoreEarnedMidTerm + shiftAmountMidTerm;
    if(totalPointsMidTerm > 100) totalPointsMidTerm = 100;
    System.out.println("Total points = " + totalPointsMidTerm + " /100");
    
    // Điểm số giữa kì:
    weightedScoreMidTerm = ((double)totalPointsMidTerm/100)*weightMidTerm;
    System.out.println("Weighted score = " + weightedScoreMidTerm + " / " + wm);
    
    System.out.println();
    
    return weightedScoreMidTerm;
  }
  
  
 // Sau đó, người dùng sẽ nhập và tính điểm thi cuối kỳ - Final
  public static double finalTerm(){
	  System.out.println("Final: ");
    Scanner sc = new Scanner(System.in);
    
  // Trọng số của 2 phần điểm thi giữa và cuối kỳ phải Nhỏ hơn 100:
  while(true){
    System.out.print("Weight  (0 - 100)?  ");
    weightFinalTerm = sc.nextInt();
       if(weightFinalTerm < 0 || weightFinalTerm > 100){
      System.out.println("Bạn đã nhập sai");
       }else{if (weightMidTerm + weightFinalTerm >100){
               System.out.println("Bạn đã nhập TỔNG TRỌNG SỐ QUÁ 100");
             }else{
              break;        
              }
        }  
    }
  String wf = String.valueOf(weightFinalTerm);
  
  while(true) {  
        System.out.print("Score earned?   ");
    scoreEarnedFinalTerm = sc.nextInt();
       if(scoreEarnedFinalTerm < 0 || scoreEarnedFinalTerm >100) {
    	       System.out.println("Vui lòng nhập trong khoảng từ 0 - 100");
       } else {
    	break;
    	 }
    }
    
        System.out.print("Were scores shifted (1 = yes, 2=no)?   ");
    WereScoresShiftedFinalTerm = sc.nextInt();
    
    if(WereScoresShiftedFinalTerm == 1){
        System.out.print("Shift amount?   ");
    shiftAmountFinalTerm = sc.nextInt(); 
    } 

    totalPointsFinalTerm = scoreEarnedFinalTerm + shiftAmountFinalTerm;
    System.out.println("totalPointsFinalTer  " + totalPointsFinalTerm);
      if(totalPointsFinalTerm > 100) totalPointsFinalTerm = 100;
       System.out.println("Total points = " + totalPointsFinalTerm + " /100");
      
      System.out.println("weightFinalTerm " + weightFinalTerm);
      
      // Điểm số cuối kì:
    weightedScoreFinalTerm = ((double)totalPointsFinalTerm / 100) * weightFinalTerm;
    System.out.println("Weighted score = " + weightedScoreFinalTerm + " / " + wf);
    
    System.out.println();
    
    return weightedScoreFinalTerm;
  }

  // Cuối cùng, người dùng sẽ nhập và tính điểm bài tập về nhà- Homework:
  public static double homework(){
	  System.out.println("Home Work");
    Scanner sc = new Scanner(System.in);
    
  // Trọng số của 3 phần điểm thi phải có tổng chính xác là 100. Nhỏ hơn hoặc lớn hơn 100 đều không được      
  while(true){
     System.out.print("Weight (0 - 100)? ");
       weightHomeWork = sc.nextInt();
      if(weightHomeWork < 0 || weightHomeWork > 100){
          System.out.println("Bạn đã nhập sai");
      }else{if ((weightMidTerm + weightFinalTerm + weightHomeWork) > 100) {
              System.out.println("Bạn đã nhập TỔNG TRỌNG SỐ QUÁ 100");
            }else if((weightMidTerm + weightFinalTerm + weightHomeWork) < 100) {
            	System.out.println("Bạn đã nhập THIẾU TRỌNG SỐ CHƯA TỚI 100");
            }else{
              break;
             }                     
        }
  
  }
  
  String wh = String.valueOf(weightHomeWork);

        System.out.print("Number of assignments?   ");
    numOfAss = sc.nextInt();

    
    ArrayList<Integer> listAssScore = new ArrayList<Integer>(numOfAss);
    ArrayList<Integer> listAssMax = new ArrayList<Integer>(numOfAss);
    // String[] arrOfStr;
    
 // * nhập xen kẽ số rồi đến xâu ký tự; nhập số thì nó chỉ lấy số thôi còn những ký tự còn lại như dấu cách hay dấu enter thì vẫn còn lưu trong bộ đệm bàn phím;thêm sc.nextLine() ở trên thì xoá được bộ đệm bàn phím đi
    //sc.nextLine(); 
    
    for(int i = 1; i <= numOfAss; i++){
      System.out.println("Assignments " + i + " score and max?   " );
      
      // Cách 1:
//     String scoremaxStr = sc.nextLine();
//     System.out.print(scoremaxStr);
//     
//     arrOfStr = scoremaxStr.split(" ");
//     System.out.print(Arrays.toString(arrOfStr));
//
//     score = Integer.parseInt(arrOfStr[0]);
//     max = Integer.parseInt(arrOfStr[1]);
      
      
     //Cách 2:
       score = sc.nextInt();
       max = sc.nextInt();
     
      listAssScore.add(score);
      listAssMax.add(max);
      
      System.out.println(listAssScore);
      System.out.println(listAssMax);
    
    }

    
    for(int i = 0; i < listAssScore.size(); i++){
      totalAssScore += listAssScore.get(i);
      totalAssMax += listAssMax.get(i);
    }
    
  // Điểm tối đa của phần Assignment là 150, nếu vượt quá thì cũng chỉ tính là 150 điểm.
    if(totalAssScore > 150) totalAssScore = 150;
    String AS = String.valueOf(totalAssScore);
    
    if(totalAssMax > 150) totalAssMax = 150;
    String AM = String.valueOf(totalAssMax);
    
    
    System.out.println(totalAssScore);
    System.out.println(totalAssMax);
    
    
     System.out.print("How many sections did you attend?   ");
    attend = sc.nextInt();
    
//    Điểm tối đa của phần Attend là 30, nếu vượt quá 30 thì vẫn chỉ tính là 30.
    int totalAttend = attend * 5;
    if(totalAttend > 30) totalAttend = 30;
    
    System.out.println("Section points = " + totalAttend + " /30");
    System.out.println("Total points = " + AS +" / " + AM);
   
// Điểm số của bài tập về nhà:
    weightedScoreHomeWork = ((double)(totalAssScore + totalAttend)/(totalAssMax +30))*weightHomeWork;
    System.out.println("Weighted score = " + weightedScoreHomeWork + " / " + wh);
    
    System.out.println();
    
    return weightedScoreHomeWork ;
  }

  
  // Hiển thị kết quả GPA cũng như thông báo nhận xét tương ứng
  public static void report(){
    overallPercentage = Math.round(weightedScoreMidTerm + weightedScoreFinalTerm + weightedScoreHomeWork);
    
    // In ra GPA để đánh giá:
    if(overallPercentage >= 85.0) GPA = 3.0;
    else if(overallPercentage >= 75.0) GPA = 2.0;
    else if(overallPercentage >= 65.0) GPA = 1.0;
    else if(overallPercentage < 60.0) GPA = 0.0;
    else GPA = 4.0;

    System.out.println("Overall Percentage = " + overallPercentage);
    System.out.println("Your grade will be at least " + GPA);
    
    // Nhận xét về học sinh:
    if(GPA == 4.0) System.out.println("Xuất sắc");
    if(GPA == 3.0) System.out.println("Chúc mừng bạn");
    if(GPA == 2.0) System.out.println("Tạm được");
    if(GPA == 1.0) System.out.println("Cố gắng nhiều lên");
    if(GPA == 0.0) System.out.println("Quá tệ");
  }
}
